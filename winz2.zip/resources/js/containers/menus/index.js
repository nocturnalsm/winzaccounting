import SetupMenu from './SetupMenu';
import AdminMenu from './AdminMenu';

export { SetupMenu, AdminMenu }